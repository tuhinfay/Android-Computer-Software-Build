# Hello Test Source

Drop the contents of this folder directly into your repo's `source/` folder
(main.py, requirements.txt, buildozer.spec) — either by dragging all 3 files
via GitHub's "Add file -> Upload files", or by putting this whole thing as
one zip inside source/.

When you run the "Build PC EXE and Android APK" workflow with:
  app_name = HelloTest
  entry_file = main.py

You'll get:
  - HelloTest.exe  (Windows) -> opens and shows "Hello test"
  - HelloTest.apk  (Android) -> opens and shows "Hello"

Both come from this SAME main.py — it detects the platform at runtime using
kivy.utils.platform and shows different text automatically. This is the
easiest way to verify your whole build pipeline works end-to-end with one
single run.
