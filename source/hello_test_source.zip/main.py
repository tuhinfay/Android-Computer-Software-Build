from kivy.app import App
from kivy.uix.label import Label
from kivy.utils import platform


class HelloApp(App):
    def build(self):
        if platform == "android":
            message = "Hello"
        else:
            message = "Hello test"
        return Label(text=message, font_size=48)


if __name__ == "__main__":
    HelloApp().run()
