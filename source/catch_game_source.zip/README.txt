Catch Game - source for the app builder pipeline

How to play:
- A red ball falls from the top of the screen.
- Drag your finger (or mouse on PC) left/right to move the blue paddle
  and catch the ball before it hits the bottom.
- Each catch = +1 score, and the ball speeds up slightly.
- Missing the ball costs 1 life (starts with 3 lives).
- When lives reach 0, a Game Over screen appears with a "Play Again" button.

How to build:
- Drop main.py, requirements.txt, and buildozer.spec directly into your
  repo's source/ folder (or upload this whole folder as one zip there).
- Run the "Build PC EXE and Android APK" workflow with:
    app_name = CatchGame
    entry_file = main.py
- You'll get CatchGame.apk (Android) and CatchGame.exe (Windows) from the
  same code -- both playable with touch (Android) or mouse-drag (PC).
