import random
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Ellipse, Rectangle, Color
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.audio import SoundLoader


BALL_RADIUS = 22
PADDLE_WIDTH = 140
PADDLE_HEIGHT = 24
LIVES_START = 3


class GameArea(Widget):
    def __init__(self, on_game_over, **kwargs):
        super().__init__(**kwargs)
        self.on_game_over = on_game_over
        self.score = 0
        self.lives = LIVES_START
        self.ball_speed = 4
        self.paddle_x = 0

        with self.canvas:
            Color(0.15, 0.55, 0.95, 1)
            self.paddle_rect = Rectangle(size=(PADDLE_WIDTH, PADDLE_HEIGHT))
            Color(0.95, 0.3, 0.25, 1)
            self.ball_shape = Ellipse(size=(BALL_RADIUS * 2, BALL_RADIUS * 2))

        self.score_label = Label(
            text="Score: 0", font_size=28, pos_hint={"x": 0.02, "top": 0.98},
            size_hint=(0.4, 0.08), halign="left"
        )
        self.lives_label = Label(
            text="Lives: " + str(LIVES_START), font_size=28,
            pos_hint={"right": 0.98, "top": 0.98}, size_hint=(0.4, 0.08),
            halign="right"
        )
        self.add_widget(self.score_label)
        self.add_widget(self.lives_label)

        self.reset_ball()
        self.bind(size=self._layout, pos=self._layout)
        Clock.schedule_interval(self.update, 1 / 60)

    def _layout(self, *args):
        self.paddle_rect.pos = (self.paddle_x, 30)

    def reset_ball(self):
        self.ball_x = random.uniform(BALL_RADIUS, max(BALL_RADIUS, self.width - BALL_RADIUS)) if self.width else 100
        self.ball_y = self.height if self.height else 600

    def on_touch_down(self, touch):
        self._move_paddle(touch.x)
        return True

    def on_touch_move(self, touch):
        self._move_paddle(touch.x)
        return True

    def _move_paddle(self, x):
        self.paddle_x = max(0, min(self.width - PADDLE_WIDTH, x - PADDLE_WIDTH / 2))
        self.paddle_rect.pos = (self.paddle_x, 30)

    def update(self, dt):
        if self.width == 0:
            return
        self.ball_y -= self.ball_speed
        self.ball_shape.pos = (self.ball_x - BALL_RADIUS, self.ball_y - BALL_RADIUS)

        paddle_top = 30 + PADDLE_HEIGHT
        if (self.ball_y - BALL_RADIUS <= paddle_top and
                self.ball_y - BALL_RADIUS > 30 and
                self.paddle_x <= self.ball_x <= self.paddle_x + PADDLE_WIDTH):
            self.score += 1
            self.score_label.text = "Score: " + str(self.score)
            self.ball_speed = min(14, self.ball_speed + 0.4)
            self.reset_ball()
        elif self.ball_y < 0:
            self.lives -= 1
            self.lives_label.text = "Lives: " + str(self.lives)
            if self.lives <= 0:
                Clock.unschedule(self.update)
                self.on_game_over(self.score)
                return
            self.reset_ball()


class RootLayout(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.game = GameArea(on_game_over=self.show_game_over, size_hint=(1, 1))
        self.add_widget(self.game)

    def show_game_over(self, score):
        self.remove_widget(self.game)
        box = FloatLayout()
        box.add_widget(Label(
            text="Game Over!\nScore: " + str(score),
            font_size=44, halign="center",
            pos_hint={"center_x": 0.5, "center_y": 0.6}, size_hint=(0.9, 0.3)
        ))
        restart_btn = Button(
            text="Play Again", font_size=30,
            pos_hint={"center_x": 0.5, "center_y": 0.35}, size_hint=(0.5, 0.12)
        )
        restart_btn.bind(on_release=lambda *_: self.restart())
        box.add_widget(restart_btn)
        self.add_widget(box)
        self._game_over_box = box

    def restart(self):
        self.remove_widget(self._game_over_box)
        self.game = GameArea(on_game_over=self.show_game_over, size_hint=(1, 1))
        self.add_widget(self.game)


class CatchGameApp(App):
    def build(self):
        Window.clearcolor = (0.05, 0.05, 0.08, 1)
        return RootLayout()


if __name__ == "__main__":
    CatchGameApp().run()
