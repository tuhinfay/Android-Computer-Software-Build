// DeskBand.h - Binance Spot Cryptocurrency Price Ticker
#pragma once
#include "pch.h"

#define APP_NAME        L"Cryptocurrency Price Ticker"
#define APP_VERSION     L"v2.1.0"
#define BAND_HEIGHT_ONE 30
#define BAND_HEIGHT_TWO 50
#define BAND_MIN_WIDTH  100
#define BAND_MAX_WIDTH  520

#define DEFAULT_INTERVAL_MS 30000
#define FAST_INTERVAL_MS    1000
#define DEFAULT_FONT_SIZE   9
#define REG_KEY             L"Software\\CryptoPriceTicker"
#define WND_CLASS           L"CryptoPriceTickerWnd"

#define WMU_PRICE_READY   (WM_USER + 1)
#define WMU_FETCH_FAILED  (WM_USER + 2)

#define IDM_COIN1          2101
#define IDM_COIN2          2102
#define IDM_COIN2_ENABLE   2103
#define IDM_FREQ_1         2110
#define IDM_FREQ_30        2111
#define IDM_FREQ_60        2112
#define IDM_FREQ_300       2113
#define IDM_PROVIDER_SPOT  2141
#define IDM_PROVIDER_FUTURES 2142
#define IDM_REFRESH        2120
#define IDM_EXIT_BAND      2121

enum class FlashState { None, Up, Down };

struct CoinSlot
{
    std::wstring symbol;       // e.g. BTCUSDT
    double price;
    double change24h;
    bool priceValid;
    bool connecting;
};

extern HINSTANCE g_hInst;
extern LONG      g_cDllRef;

static const CLSID CLSID_DeskBand =
{ 0xb1c2d3e4, 0xf5a6, 0x7b8c,
  { 0x9d, 0x0e, 0xf1, 0xa2, 0xb3, 0xc4, 0xd5, 0xe6 } };

class CDeskBand : public IDeskBand2,
                  public IObjectWithSite,
                  public IPersistStream
{
public:
    CDeskBand();
    virtual ~CDeskBand();

    STDMETHOD_(ULONG, AddRef)()  override;
    STDMETHOD_(ULONG, Release)() override;
    STDMETHOD(QueryInterface)(REFIID riid, void** ppv) override;

    STDMETHOD(GetWindow)(HWND* phwnd) override;
    STDMETHOD(ContextSensitiveHelp)(BOOL) override { return E_NOTIMPL; }
    STDMETHOD(ShowDW)(BOOL bShow) override;
    STDMETHOD(CloseDW)(DWORD) override;
    STDMETHOD(ResizeBorderDW)(const RECT*, IUnknown*, BOOL) override { return E_NOTIMPL; }
    STDMETHOD(GetBandInfo)(DWORD dwBandID, DWORD dwViewMode, DESKBANDINFO* pdbi) override;

    STDMETHOD(CanRenderComposited)(BOOL* pfCan) override;
    STDMETHOD(SetCompositionState)(BOOL bEnabled) override;
    STDMETHOD(GetCompositionState)(BOOL* pb) override;

    STDMETHOD(SetSite)(IUnknown* pUnkSite) override;
    STDMETHOD(GetSite)(REFIID riid, void** ppvSite) override;

    STDMETHOD(GetClassID)(CLSID* pClassID) override;
    STDMETHOD(IsDirty)() override { return S_FALSE; }
    STDMETHOD(Load)(IStream*) override { return S_OK; }
    STDMETHOD(Save)(IStream*, BOOL) override { return S_OK; }
    STDMETHOD(GetSizeMax)(ULARGE_INTEGER*) override { return E_NOTIMPL; }

private:
    BOOL CreateBandWindow(HWND hwndParent);
    void DestroyBandWindow();
    void RebuildFont();
    int  MeasureText(const std::wstring& text);
    int  CalcIdealWidth();
    int  CalcIdealHeight();

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
    LRESULT OnMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
    void OnCommand(WORD cmd);

    void OnPaint(HWND hwnd);
    void ShowContextMenu(HWND hwnd);

    void StartTimer();
    void StopTimers();
    void TriggerFetch();
    void FetchThread(std::wstring coin1, std::wstring coin2, bool coin2Enabled, bool useFutures);

    bool FetchBinance(const std::wstring& symbol, double& outPrice, double& outChange, bool useFutures);
    bool HttpsGet(const std::wstring& host, const std::wstring& path, std::string& outBody);
    static bool ExtractDouble(const std::string& json, const std::string& key, double& outVal);

    void LoadSettings();
    void SaveSettings();

    static std::wstring NormalizeSymbol(const std::wstring& input);
    static bool AskForCoin(HWND owner, const std::wstring& current, std::wstring& result);
    static INT_PTR CALLBACK CoinDialogProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
    static bool IsSystemDark();

private:
    LONG      m_cRef;
    IUnknown* m_pSite;
    HWND      m_hwnd;
    HWND      m_hwndParent;
    DWORD     m_dwBandID;
    BOOL      m_bCompositionEnabled;

    CoinSlot  m_coin[2];
    bool      m_coin2Enabled;
    DWORD     m_intervalMs;
    bool      m_useFutures;

    std::mutex m_mutex;
    UINT_PTR  m_updateTimerID;
    std::thread m_thread;
    std::atomic<bool> m_fetching;

    HFONT m_hFont;
};
