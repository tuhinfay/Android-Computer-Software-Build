// DeskBand.cpp - Binance Spot two-line taskbar cryptocurrency ticker
#include "pch.h"
#include "DeskBand.h"

static const COLORREF CLR_UP   = RGB(50, 220, 50);
static const COLORREF CLR_DOWN = RGB(255, 80, 70);
static const int IDC_COIN_EDIT = 1001;

static bool ExtractDoubleAllowNegative(const std::string& json, const std::string& key, double& outVal);

static std::wstring TrimWS(std::wstring s)
{
    while (!s.empty() && iswspace(s.front())) s.erase(s.begin());
    while (!s.empty() && iswspace(s.back())) s.pop_back();
    return s;
}

CDeskBand::CDeskBand()
    : m_cRef(1), m_pSite(nullptr), m_hwnd(nullptr), m_hwndParent(nullptr),
      m_dwBandID(0), m_bCompositionEnabled(FALSE),
      m_coin2Enabled(true), m_intervalMs(DEFAULT_INTERVAL_MS), m_useFutures(false),
      m_updateTimerID(0), m_fetching(false), m_hFont(nullptr)
{
    m_coin[0] = { L"BTCUSDT", 0.0, 0.0, false, false };
    m_coin[1] = { L"ETHUSDT", 0.0, 0.0, false, false };
    InterlockedIncrement(&g_cDllRef);
    LoadSettings();
    RebuildFont();
}

CDeskBand::~CDeskBand()
{
    StopTimers();
    if (m_thread.joinable()) m_thread.join();
    DestroyBandWindow();
    if (m_pSite) m_pSite->Release();
    if (m_hFont) DeleteObject(m_hFont);
    InterlockedDecrement(&g_cDllRef);
}

ULONG CDeskBand::AddRef() { return InterlockedIncrement(&m_cRef); }
ULONG CDeskBand::Release()
{
    ULONG c = InterlockedDecrement(&m_cRef);
    if (!c) delete this;
    return c;
}

HRESULT CDeskBand::QueryInterface(REFIID riid, void** ppv)
{
    if (!ppv) return E_POINTER;
    *ppv = nullptr;
    if (IsEqualIID(riid, IID_IUnknown) ||
        IsEqualIID(riid, IID_IOleWindow) ||
        IsEqualIID(riid, IID_IDockingWindow) ||
        IsEqualIID(riid, IID_IDeskBand) ||
        IsEqualIID(riid, IID_IDeskBand2))
        *ppv = static_cast<IDeskBand2*>(this);
    else if (IsEqualIID(riid, IID_IObjectWithSite))
        *ppv = static_cast<IObjectWithSite*>(this);
    else if (IsEqualIID(riid, IID_IPersist) ||
             IsEqualIID(riid, IID_IPersistStream))
        *ppv = static_cast<IPersistStream*>(this);
    else return E_NOINTERFACE;
    AddRef();
    return S_OK;
}

HRESULT CDeskBand::GetWindow(HWND* phwnd)
{
    if (!phwnd) return E_POINTER;
    *phwnd = m_hwnd;
    return m_hwnd ? S_OK : E_FAIL;
}

HRESULT CDeskBand::ShowDW(BOOL bShow)
{
    if (m_hwnd) ShowWindow(m_hwnd, bShow ? SW_SHOW : SW_HIDE);
    return S_OK;
}

HRESULT CDeskBand::CloseDW(DWORD)
{
    StopTimers();
    ShowDW(FALSE);
    DestroyBandWindow();
    return S_OK;
}

int CDeskBand::CalcIdealHeight()
{
    return m_coin2Enabled ? BAND_HEIGHT_TWO : BAND_HEIGHT_ONE;
}

HRESULT CDeskBand::GetBandInfo(DWORD dwBandID, DWORD, DESKBANDINFO* pdbi)
{
    if (!pdbi) return E_INVALIDARG;
    m_dwBandID = dwBandID;
    int w = CalcIdealWidth();
    int h = CalcIdealHeight();

    if (pdbi->dwMask & DBIM_MINSIZE) { pdbi->ptMinSize.x = w; pdbi->ptMinSize.y = h; }
    if (pdbi->dwMask & DBIM_MAXSIZE) { pdbi->ptMaxSize.x = w; pdbi->ptMaxSize.y = h; }
    if (pdbi->dwMask & DBIM_ACTUAL)  { pdbi->ptActual.x = w; pdbi->ptActual.y = h; }
    if (pdbi->dwMask & DBIM_TITLE) pdbi->wszTitle[0] = L'\0';
    if (pdbi->dwMask & DBIM_MODEFLAGS)
        pdbi->dwModeFlags = DBIMF_NORMAL | DBIMF_VARIABLEHEIGHT;
    if (pdbi->dwMask & DBIM_BKCOLOR) pdbi->dwMask &= ~DBIM_BKCOLOR;
    return S_OK;
}

HRESULT CDeskBand::CanRenderComposited(BOOL* p)
{
    if (p) *p = TRUE;
    return S_OK;
}
HRESULT CDeskBand::SetCompositionState(BOOL b)
{
    m_bCompositionEnabled = b;
    if (m_hwnd) InvalidateRect(m_hwnd, nullptr, TRUE);
    return S_OK;
}
HRESULT CDeskBand::GetCompositionState(BOOL* p)
{
    if (p) *p = m_bCompositionEnabled;
    return S_OK;
}

HRESULT CDeskBand::SetSite(IUnknown* pUnkSite)
{
    if (m_pSite) { m_pSite->Release(); m_pSite = nullptr; }
    DestroyBandWindow();
    StopTimers();
    if (!pUnkSite) return S_OK;

    IOleWindow* pOW = nullptr;
    if (FAILED(pUnkSite->QueryInterface(IID_IOleWindow, (void**)&pOW)))
        return E_FAIL;
    pOW->GetWindow(&m_hwndParent);
    pOW->Release();
    if (!m_hwndParent) return E_FAIL;

    m_pSite = pUnkSite;
    m_pSite->AddRef();

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = CDeskBand::WndProc;
    wc.hInstance = g_hInst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = nullptr;
    wc.lpszClassName = WND_CLASS;
    RegisterClassExW(&wc);

    CreateBandWindow(m_hwndParent);
    StartTimer();
    TriggerFetch();
    return S_OK;
}

HRESULT CDeskBand::GetSite(REFIID riid, void** ppvSite)
{
    if (!ppvSite) return E_POINTER;
    if (!m_pSite) { *ppvSite = nullptr; return E_FAIL; }
    return m_pSite->QueryInterface(riid, ppvSite);
}

HRESULT CDeskBand::GetClassID(CLSID* p)
{
    if (!p) return E_POINTER;
    *p = CLSID_DeskBand;
    return S_OK;
}

BOOL CDeskBand::CreateBandWindow(HWND hwndParent)
{
    m_hwnd = CreateWindowExW(
        WS_EX_TRANSPARENT, WND_CLASS, nullptr,
        WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
        0, 0, BAND_MIN_WIDTH, CalcIdealHeight(),
        hwndParent, nullptr, g_hInst, this);
    return m_hwnd != nullptr;
}

void CDeskBand::DestroyBandWindow()
{
    if (m_hwnd) { DestroyWindow(m_hwnd); m_hwnd = nullptr; }
}

void CDeskBand::RebuildFont()
{
    if (m_hFont) { DeleteObject(m_hFont); m_hFont = nullptr; }
    LOGFONTW lf = {};
    HDC hdc = GetDC(nullptr);
    lf.lfHeight = -MulDiv(DEFAULT_FONT_SIZE, GetDeviceCaps(hdc, LOGPIXELSY), 72);
    ReleaseDC(nullptr, hdc);
    lf.lfWeight = FW_NORMAL;
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfQuality = CLEARTYPE_QUALITY;
    wcscpy_s(lf.lfFaceName, L"Segoe UI");
    m_hFont = CreateFontIndirectW(&lf);
}

int CDeskBand::MeasureText(const std::wstring& text)
{
    if (!m_hFont) return BAND_MIN_WIDTH;
    HDC hdc = GetDC(nullptr);
    HFONT old = (HFONT)SelectObject(hdc, m_hFont);
    SIZE sz = {};
    GetTextExtentPoint32W(hdc, text.c_str(), (int)text.size(), &sz);
    SelectObject(hdc, old);
    ReleaseDC(nullptr, hdc);
    return sz.cx;
}

static std::wstring FormatPrice(double price)
{
    wchar_t buf[64] = {};
    if (price >= 10000.0) swprintf_s(buf, L"%.2f", price);
    else if (price >= 1.0) swprintf_s(buf, L"%.4f", price);
    else if (price >= 0.01) swprintf_s(buf, L"%.6f", price);
    else swprintf_s(buf, L"%.8f", price);

    std::wstring s(buf);
    size_t dot = s.find(L'.');
    size_t end = dot == std::wstring::npos ? s.size() : dot;
    int pos = (int)end - 3;
    while (pos > 0) { s.insert(pos, 1, L','); pos -= 3; }
    return s;
}

int CDeskBand::CalcIdealWidth()
{
    std::lock_guard<std::mutex> lock(m_mutex);

    std::wstring longest;
    for (int i = 0; i < (m_coin2Enabled ? 2 : 1); ++i)
    {
        std::wstring sym = m_coin[i].symbol;
        if (sym.size() > 4 && sym.substr(sym.size()-4) == L"USDT")
            sym.resize(sym.size()-4);

        std::wstring row;
        if (!m_coin[i].priceValid)
            row = sym + L" Refreshing...";
        else
        {
            wchar_t chg[32];
            swprintf_s(chg, L" %s %.2f%%",
                m_coin[i].change24h >= 0 ? L"\x25B2" : L"\x25BC",
                m_coin[i].change24h);
            row = sym + L" $" + FormatPrice(m_coin[i].price) + chg;
        }
        if (MeasureText(row) > MeasureText(longest)) longest = row;
    }
    int w = MeasureText(longest) + 20;
    if (w < BAND_MIN_WIDTH) w = BAND_MIN_WIDTH;
    if (w > BAND_MAX_WIDTH) w = BAND_MAX_WIDTH;
    return w;
}

LRESULT CALLBACK CDeskBand::WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    CDeskBand* p = nullptr;
    if (msg == WM_NCCREATE)
    {
        auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
        p = reinterpret_cast<CDeskBand*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, (LONG_PTR)p);
    }
    else p = reinterpret_cast<CDeskBand*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));

    return p ? p->OnMessage(hwnd, msg, wp, lp) : DefWindowProcW(hwnd, msg, wp, lp);
}

LRESULT CDeskBand::OnMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg)
    {
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: OnPaint(hwnd); return 0;

    case WM_TIMER:
        if ((UINT_PTR)wp == m_updateTimerID) TriggerFetch();
        return 0;

    case WMU_PRICE_READY:
    case WMU_FETCH_FAILED:
    {
        int w = CalcIdealWidth();
        int h = CalcIdealHeight();
        SetWindowPos(hwnd, nullptr, 0, 0, w, h,
                     SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
        HWND parent = GetParent(hwnd);
        if (parent) SendMessageW(parent, WM_SIZE, 0, 0);
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_RBUTTONUP:
        ShowContextMenu(hwnd);
        return 0;

    case WM_LBUTTONDBLCLK:
        TriggerFetch();
        return 0;

    case WM_COMMAND:
        OnCommand(LOWORD(wp));
        return 0;

    case WM_DESTROY:
        StopTimers();
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

void CDeskBand::OnCommand(WORD cmd)
{
    if (cmd == IDM_COIN1 || cmd == IDM_COIN2)
    {
        int slot = (cmd == IDM_COIN1) ? 0 : 1;
        std::wstring result;
        if (AskForCoin(m_hwnd, m_coin[slot].symbol, result))
        {
            m_coin[slot].symbol = result;
            m_coin[slot].priceValid = false;
            SaveSettings();
            TriggerFetch();
        }
        return;
    }

    switch (cmd)
    {
    case IDM_COIN2_ENABLE:
        m_coin2Enabled = !m_coin2Enabled;
        SaveSettings();
        if (m_hwnd)
        {
            int w = CalcIdealWidth(), h = CalcIdealHeight();
            SetWindowPos(m_hwnd, nullptr, 0, 0, w, h,
                         SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
            SendMessageW(GetParent(m_hwnd), WM_SIZE, 0, 0);
            InvalidateRect(m_hwnd, nullptr, TRUE);
        }
        TriggerFetch();
        break;

    case IDM_FREQ_1:
        m_intervalMs = FAST_INTERVAL_MS; StopTimers(); StartTimer(); SaveSettings(); break;
    case IDM_FREQ_30:
        m_intervalMs = 30000; StopTimers(); StartTimer(); SaveSettings(); break;
    case IDM_FREQ_60:
        m_intervalMs = 60000; StopTimers(); StartTimer(); SaveSettings(); break;
    case IDM_FREQ_300:
        m_intervalMs = 300000; StopTimers(); StartTimer(); SaveSettings(); break;
    case IDM_PROVIDER_SPOT:
        m_useFutures = false; SaveSettings(); TriggerFetch(); break;
    case IDM_PROVIDER_FUTURES:
        m_useFutures = true; SaveSettings(); TriggerFetch(); break;
    case IDM_REFRESH:
        TriggerFetch(); break;
    }
}

void CDeskBand::ShowContextMenu(HWND hwnd)
{
    HMENU hMenu = CreatePopupMenu();
    if (!hMenu) return;

    AppendMenuW(hMenu, MF_STRING | MF_GRAYED | MF_DISABLED, 0, APP_VERSION);
    AppendMenuW(hMenu, MF_SEPARATOR, 0, nullptr);

    HMENU hCoins = CreatePopupMenu();
    std::wstring c1 = L"Coin 1: " + m_coin[0].symbol;
    std::wstring c2 = L"Coin 2: " + m_coin[1].symbol;
    AppendMenuW(hCoins, MF_STRING, IDM_COIN1, c1.c_str());
    AppendMenuW(hCoins, MF_STRING, IDM_COIN2, c2.c_str());
    AppendMenuW(hCoins, MF_STRING | (m_coin2Enabled ? MF_CHECKED : 0),
                IDM_COIN2_ENABLE, L"Show Coin 2");
    AppendMenuW(hMenu, MF_POPUP, (UINT_PTR)hCoins, L"Coins (Binance Spot)");

    HMENU hFreq = CreatePopupMenu();
    AppendMenuW(hFreq, MF_STRING | (m_intervalMs == FAST_INTERVAL_MS ? MF_CHECKED : 0),
                IDM_FREQ_1, L"1 second");
    AppendMenuW(hFreq, MF_STRING | (m_intervalMs == 30000 ? MF_CHECKED : 0),
                IDM_FREQ_30, L"30 seconds");
    AppendMenuW(hFreq, MF_STRING | (m_intervalMs == 60000 ? MF_CHECKED : 0),
                IDM_FREQ_60, L"1 minute");
    AppendMenuW(hFreq, MF_STRING | (m_intervalMs == 300000 ? MF_CHECKED : 0),
                IDM_FREQ_300, L"5 minutes");
    AppendMenuW(hMenu, MF_POPUP, (UINT_PTR)hFreq, L"Update Frequency");

    HMENU hProvider = CreatePopupMenu();
    AppendMenuW(hProvider, MF_STRING | (!m_useFutures ? MF_CHECKED : 0), IDM_PROVIDER_SPOT, L"Binance Spot");
    AppendMenuW(hProvider, MF_STRING | (m_useFutures ? MF_CHECKED : 0), IDM_PROVIDER_FUTURES, L"Binance Futures");
    AppendMenuW(hMenu, MF_POPUP, (UINT_PTR)hProvider, L"Market");

    AppendMenuW(hMenu, MF_STRING, IDM_REFRESH, L"Refresh now");

    POINT pt;
    GetCursorPos(&pt);
    SetForegroundWindow(hwnd);
    TrackPopupMenu(hMenu, TPM_RIGHTBUTTON | TPM_BOTTOMALIGN,
                   pt.x, pt.y, 0, hwnd, nullptr);

    DestroyMenu(hProvider);
    DestroyMenu(hFreq);
    DestroyMenu(hCoins);
    DestroyMenu(hMenu);
}

bool CDeskBand::IsSystemDark()
{
    HKEY hKey = nullptr;
    DWORD val = 1, sz = sizeof(val);
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
        0, KEY_READ, &hKey) == ERROR_SUCCESS)
    {
        RegQueryValueExW(hKey, L"SystemUsesLightTheme", nullptr, nullptr,
                         (BYTE*)&val, &sz);
        RegCloseKey(hKey);
    }
    return val == 0;
}

void CDeskBand::OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    RECT rc; GetClientRect(hwnd, &rc);
    int w = rc.right, h = rc.bottom;

    HDC mem = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(mem, bmp);

    HBRUSH bg = CreateSolidBrush(RGB(0,0,0));
    FillRect(mem, &rc, bg);
    DeleteObject(bg);

    SelectObject(mem, m_hFont);
    SetBkMode(mem, TRANSPARENT);

    std::lock_guard<std::mutex> lock(m_mutex);

    for (int i = 0; i < (m_coin2Enabled ? 2 : 1); ++i)
    {
        int rowH = m_coin2Enabled ? h / 2 : h;
        RECT rr = { 6, i * rowH, w - 6, (i + 1) * rowH };

        std::wstring sym = m_coin[i].symbol;
        if (sym.size() > 4 && sym.substr(sym.size()-4) == L"USDT")
            sym.resize(sym.size()-4);

        SetTextColor(mem, RGB(255,255,255));

        if (!m_coin[i].priceValid)
        {
            std::wstring text = sym + L" Refreshing...";
            DrawTextW(mem, text.c_str(), -1, &rr,
                      DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
            continue;
        }

        std::wstring base = sym + L" $" + FormatPrice(m_coin[i].price);
        wchar_t chg[32];
        swprintf_s(chg, L"  %s %.2f%%",
                   m_coin[i].change24h >= 0 ? L"\x25B2" : L"\x25BC",
                   m_coin[i].change24h);

        DrawTextW(mem, base.c_str(), -1, &rr,
                  DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);

        int baseW = MeasureText(base);
        RECT cr = rr; cr.left += baseW;
        SetTextColor(mem, m_coin[i].change24h >= 0 ? CLR_UP : CLR_DOWN);
        DrawTextW(mem, chg, -1, &cr,
                  DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
    }

    BitBlt(hdc, 0, 0, w, h, mem, 0, 0, SRCCOPY);
    SelectObject(mem, oldBmp);
    DeleteObject(bmp);
    DeleteDC(mem);
    EndPaint(hwnd, &ps);
}

void CDeskBand::StartTimer()
{
    if (m_hwnd)
        m_updateTimerID = SetTimer(m_hwnd, 1, m_intervalMs, nullptr);
}

void CDeskBand::StopTimers()
{
    if (m_hwnd && m_updateTimerID)
    {
        KillTimer(m_hwnd, m_updateTimerID);
        m_updateTimerID = 0;
    }
}

void CDeskBand::TriggerFetch()
{
    if (m_fetching) return;
    if (m_thread.joinable()) m_thread.join();

    std::wstring c1, c2;
    bool enabled;
    bool useFutures;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        c1 = m_coin[0].symbol;
        c2 = m_coin[1].symbol;
        enabled = m_coin2Enabled;
        useFutures = m_useFutures;
        m_coin[0].connecting = true;
        m_coin[1].connecting = enabled;
    }

    m_fetching = true;
    if (m_hwnd) InvalidateRect(m_hwnd, nullptr, FALSE);

    m_thread = std::thread([this, c1, c2, enabled, useFutures]()
    {
        FetchThread(c1, c2, enabled, useFutures);
    });
}

void CDeskBand::FetchThread(std::wstring coin1, std::wstring coin2, bool coin2Enabled, bool useFutures)
{
    double p = 0.0, ch = 0.0;
    bool ok1 = FetchBinance(coin1, p, ch, useFutures);

    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_coin[0].connecting = false;
        if (ok1)
        {
            m_coin[0].price = p;
            m_coin[0].change24h = ch;
            m_coin[0].priceValid = true;
        }
    }

    bool ok2 = false;
    if (coin2Enabled)
    {
        p = ch = 0.0;
        ok2 = FetchBinance(coin2, p, ch, useFutures);
        std::lock_guard<std::mutex> lock(m_mutex);
        m_coin[1].connecting = false;
        if (ok2)
        {
            m_coin[1].price = p;
            m_coin[1].change24h = ch;
            m_coin[1].priceValid = true;
        }
    }

    m_fetching = false;
    if (m_hwnd)
        PostMessageW(m_hwnd, (ok1 || ok2) ? WMU_PRICE_READY : WMU_FETCH_FAILED, 0, 0);
}

bool CDeskBand::FetchBinance(const std::wstring& symbol,
                              double& outPrice, double& outChange, bool useFutures)
{
    std::wstring s = NormalizeSymbol(symbol);
    if (s.empty()) return false;

    const wchar_t* host = useFutures ? L"fapi.binance.com" : L"api.binance.com";
    std::wstring path = useFutures
        ? L"/fapi/v1/ticker/24hr?symbol=" + s
        : L"/api/v3/ticker/24hr?symbol=" + s;

    std::string body;
    if (!HttpsGet(host, path, body)) return false;

    bool p = ExtractDouble(body, "\"lastPrice\"", outPrice);
    bool c = ExtractDoubleAllowNegative(body, "\"priceChangePercent\"", outChange);
    return p && c && outPrice > 0.0;
}

bool CDeskBand::HttpsGet(const std::wstring& host,
                         const std::wstring& path,
                         std::string& outBody)
{
    outBody.clear();
    HINTERNET hS = WinHttpOpen(L"CryptoPriceTicker/2.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hS) return false;

    HINTERNET hC = WinHttpConnect(hS, host.c_str(),
        INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hC) { WinHttpCloseHandle(hS); return false; }

    HINTERNET hR = WinHttpOpenRequest(hC, L"GET", path.c_str(),
        nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);
    if (!hR) {
        WinHttpCloseHandle(hC); WinHttpCloseHandle(hS); return false;
    }

    DWORD timeout = 15000;
    WinHttpSetOption(hR, WINHTTP_OPTION_CONNECT_TIMEOUT, &timeout, sizeof(timeout));
    WinHttpSetOption(hR, WINHTTP_OPTION_RECEIVE_TIMEOUT, &timeout, sizeof(timeout));

    bool ok = false;
    if (WinHttpSendRequest(hR, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                           WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
        WinHttpReceiveResponse(hR, nullptr))
    {
        DWORD status = 0, sz = sizeof(status);
        WinHttpQueryHeaders(hR,
            WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz,
            WINHTTP_NO_HEADER_INDEX);

        if (status == 200)
        {
            DWORD read = 0;
            char buf[4096];
            do {
                read = 0;
                if (!WinHttpReadData(hR, buf, sizeof(buf) - 1, &read)) break;
                if (read) { buf[read] = '\0'; outBody.append(buf, read); }
            } while (read > 0);
            ok = !outBody.empty();
        }
    }

    WinHttpCloseHandle(hR);
    WinHttpCloseHandle(hC);
    WinHttpCloseHandle(hS);
    return ok;
}

bool CDeskBand::ExtractDouble(const std::string& json,
                              const std::string& key, double& outVal)
{
    size_t pos = json.find(key);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos);
    if (pos == std::string::npos) return false;
    ++pos;
    while (pos < json.size() &&
           (json[pos]==' ' || json[pos]=='\t' || json[pos]=='\r' ||
            json[pos]=='\n' || json[pos]=='"')) ++pos;
    try { outVal = std::stod(json.substr(pos)); return true; }
    catch (...) { return false; }
}

bool ExtractDoubleAllowNegative(const std::string& json,
                                const std::string& key, double& outVal)
{
    size_t pos = json.find(key);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos);
    if (pos == std::string::npos) return false;
    ++pos;
    while (pos < json.size() &&
           (json[pos]==' ' || json[pos]=='\t' || json[pos]=='\r' ||
            json[pos]=='\n' || json[pos]=='"')) ++pos;
    try { outVal = std::stod(json.substr(pos)); return true; }
    catch (...) { return false; }
}

std::wstring CDeskBand::NormalizeSymbol(const std::wstring& input)
{
    std::wstring s = TrimWS(input);
    std::wstring out;
    for (wchar_t ch : s)
    {
        if (ch == L'/' || ch == L'-' || ch == L' ' || ch == L'\t') continue;
        out.push_back((wchar_t)towupper(ch));
    }
    if (out.empty()) return L"";
    if (out.size() < 4 || out.substr(out.size()-4) != L"USDT")
        out += L"USDT";

    if (out.size() > 24) return L"";
    for (wchar_t ch : out)
        if (!((ch >= L'A' && ch <= L'Z') || (ch >= L'0' && ch <= L'9')))
            return L"";
    return out;
}

void CDeskBand::LoadSettings()
{
    HKEY hKey = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, REG_KEY, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
        return;

    auto ReadString = [&](const wchar_t* name, std::wstring& dest)
    {
        DWORD type = 0, sz = 0;
        if (RegQueryValueExW(hKey, name, nullptr, &type, nullptr, &sz) == ERROR_SUCCESS &&
            type == REG_SZ && sz > sizeof(wchar_t))
        {
            std::vector<wchar_t> buf(sz / sizeof(wchar_t) + 1);
            if (RegQueryValueExW(hKey, name, nullptr, nullptr,
                                 (BYTE*)buf.data(), &sz) == ERROR_SUCCESS)
                dest = NormalizeSymbol(buf.data());
        }
    };

    ReadString(L"Coin1", m_coin[0].symbol);
    ReadString(L"Coin2", m_coin[1].symbol);

    DWORD val = 0, sz = sizeof(val);
    if (RegQueryValueExW(hKey, L"Coin2Enabled", nullptr, nullptr,
                         (BYTE*)&val, &sz) == ERROR_SUCCESS)
        m_coin2Enabled = val != 0;

    sz = sizeof(val);
    if (RegQueryValueExW(hKey, L"IntervalMs", nullptr, nullptr,
                         (BYTE*)&val, &sz) == ERROR_SUCCESS &&
        (val == FAST_INTERVAL_MS || val == 30000 || val == 60000 || val == 300000))
        m_intervalMs = val;

    sz = sizeof(val);
    if (RegQueryValueExW(hKey, L"UseFutures", nullptr, nullptr,
                         (BYTE*)&val, &sz) == ERROR_SUCCESS)
        m_useFutures = val != 0;

    RegCloseKey(hKey);
}

void CDeskBand::SaveSettings()
{
    HKEY hKey = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REG_KEY, 0, nullptr,
        REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr) != ERROR_SUCCESS)
        return;

    auto WriteString = [&](const wchar_t* name, const std::wstring& value)
    {
        RegSetValueExW(hKey, name, 0, REG_SZ,
                       (const BYTE*)value.c_str(),
                       (DWORD)((value.size()+1) * sizeof(wchar_t)));
    };

    WriteString(L"Coin1", NormalizeSymbol(m_coin[0].symbol));
    WriteString(L"Coin2", NormalizeSymbol(m_coin[1].symbol));

    DWORD v = m_coin2Enabled ? 1 : 0;
    RegSetValueExW(hKey, L"Coin2Enabled", 0, REG_DWORD, (BYTE*)&v, sizeof(v));
    v = m_intervalMs;
    RegSetValueExW(hKey, L"IntervalMs", 0, REG_DWORD, (BYTE*)&v, sizeof(v));
    v = m_useFutures ? 1 : 0;
    RegSetValueExW(hKey, L"UseFutures", 0, REG_DWORD, (BYTE*)&v, sizeof(v));

    RegCloseKey(hKey);
}

struct CoinDialogData
{
    std::wstring current;
    std::wstring result;
    bool accepted;
};

static void AlignDlgFont(HWND hDlg)
{
    HFONT font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    SendMessageW(hDlg, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageW(GetDlgItem(hDlg, IDC_COIN_EDIT), WM_SETFONT, (WPARAM)font, TRUE);
}

INT_PTR CALLBACK CDeskBand::CoinDialogProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    CoinDialogData* data = reinterpret_cast<CoinDialogData*>(
        GetWindowLongPtrW(hwnd, GWLP_USERDATA));

    if (msg == WM_INITDIALOG)
    {
        data = reinterpret_cast<CoinDialogData*>(lp);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, (LONG_PTR)data);
        SetDlgItemTextW(hwnd, IDC_COIN_EDIT, data->current.c_str());
        AlignDlgFont(hwnd);
        SetFocus(GetDlgItem(hwnd, IDC_COIN_EDIT));
        SendDlgItemMessageW(hwnd, IDC_COIN_EDIT, EM_SETSEL, 0, -1);
        return FALSE;
    }

    if (msg == WM_COMMAND)
    {
        if (LOWORD(wp) == IDOK)
        {
            wchar_t buf[128] = {};
            GetDlgItemTextW(hwnd, IDC_COIN_EDIT, buf, 128);
            std::wstring normalized = NormalizeSymbol(buf);
            if (normalized.empty())
            {
                MessageBoxW(hwnd, L"Enter a valid Binance coin symbol, e.g. BTC, ETH, SOLUSDT.",
                            APP_NAME, MB_ICONWARNING);
                return TRUE;
            }
            data->result = normalized;
            data->accepted = true;
            EndDialog(hwnd, IDOK);
            return TRUE;
        }
        if (LOWORD(wp) == IDCANCEL)
        {
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
        }
    }
    return FALSE;
}

static void DlgWord(std::vector<BYTE>& b, WORD v)
{
    b.push_back((BYTE)(v & 0xff));
    b.push_back((BYTE)((v >> 8) & 0xff));
}
static void DlgDword(std::vector<BYTE>& b, DWORD v)
{
    DlgWord(b, (WORD)(v & 0xffff));
    DlgWord(b, (WORD)((v >> 16) & 0xffff));
}
static void DlgString(std::vector<BYTE>& b, const wchar_t* s)
{
    while (*s) { DlgWord(b, (WORD)*s); ++s; }
    DlgWord(b, 0);
}
static void DlgAlign(std::vector<BYTE>& b)
{
    while (b.size() % 4) b.push_back(0);
}

bool CDeskBand::AskForCoin(HWND owner, const std::wstring& current, std::wstring& result)
{
    std::vector<BYTE> b;
    b.reserve(512);

    DlgDword(b, DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU);
    DlgWord(b, 0); // exstyle
    DlgWord(b, 4); // controls
    DlgWord(b, 10); DlgWord(b, 10); DlgWord(b, 210); DlgWord(b, 72);
    DlgString(b, L"Select Binance coin");
    DlgWord(b, 9); // font size
    DlgString(b, L"Segoe UI");

    DlgAlign(b);
    // static label
    DlgDword(b, WS_CHILD | WS_VISIBLE);
    DlgDword(b, 0);
    DlgWord(b, 0xFFFF); DlgWord(b, 0x0082);
    DlgWord(b, 8); DlgWord(b, 8); DlgWord(b, 190); DlgWord(b, 10);
    DlgWord(b, 0); DlgString(b, L"Type coin symbol (USDT pair):");

    DlgAlign(b);
    // edit
    DlgDword(b, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL);
    DlgDword(b, WS_EX_CLIENTEDGE);
    DlgWord(b, 0xFFFF); DlgWord(b, 0x0081);
    DlgWord(b, 8); DlgWord(b, 21); DlgWord(b, 190); DlgWord(b, 14);
    DlgWord(b, IDC_COIN_EDIT); DlgString(b, L"");

    DlgAlign(b);
    // OK
    DlgDword(b, WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON);
    DlgDword(b, 0);
    DlgWord(b, 0xFFFF); DlgWord(b, 0x0080);
    DlgWord(b, 102); DlgWord(b, 44); DlgWord(b, 45); DlgWord(b, 14);
    DlgWord(b, IDOK); DlgString(b, L"OK");

    DlgAlign(b);
    // Cancel
    DlgDword(b, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON);
    DlgDword(b, 0);
    DlgWord(b, 0xFFFF); DlgWord(b, 0x0080);
    DlgWord(b, 153); DlgWord(b, 44); DlgWord(b, 45); DlgWord(b, 14);
    DlgWord(b, IDCANCEL); DlgString(b, L"Cancel");

    CoinDialogData data{ current, L"", false };
    INT_PTR r = DialogBoxIndirectParamW(g_hInst,
        reinterpret_cast<DLGTEMPLATE*>(b.data()), owner,
        CoinDialogProc, (LPARAM)&data);

    if (r == IDOK && data.accepted)
    {
        result = data.result;
        return true;
    }
    return false;
}
