#define MyAppName "Cryptocurrency Price Ticker"
#define MyAppVersion "2.1.0"
#define MyAppPublisher "CryptoPriceTicker"
#define MyAppExeName "DeskBand.dll"

[Setup]
AppId={{B1C2D3E4-F5A6-7B8C-9D0E-F1A2B3C4D5E6}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\CryptoPriceTicker
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
OutputDir=installer
OutputBaseFilename=CryptoPriceTicker-v{#MyAppVersion}-x64-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\DeskBand.dll

[Files]
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "BUILD-INSTALL.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "x64\Release\DeskBand.dll"; DestDir: "{app}"; Flags: ignoreversion restartreplace

[UninstallRun]
Filename: "{sys}\regsvr32.exe"; Parameters: "/u /s ""{app}\DeskBand.dll"""; Flags: runhidden waituntilterminated

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
begin
  Result := '';
  NeedsRestart := False;
  if FileExists(ExpandConstant('{app}\DeskBand.dll')) then
  begin
    Exec(ExpandConstant('{sys}\regsvr32.exe'), '/u /s "' + ExpandConstant('{app}\DeskBand.dll') + '"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;

[Run]
Filename: "{sys}\regsvr32.exe"; Parameters: '/s "{app}\DeskBand.dll"'; Flags: runhidden waituntilterminated; StatusMsg: "Registering taskbar ticker..."
Filename: "{app}\README.md"; Description: "Open installation/configuration guide"; Flags: postinstall shellexec skipifsilent unchecked
