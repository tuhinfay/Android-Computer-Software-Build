# CryptoPriceTicker v2.1.0 - Automatic Local + GitHub Build

## Local build

Double-click `build-local.bat`. It checks for MSBuild/C++ tools and Inno Setup. If missing, it automatically runs `setup-dev.bat` as Administrator, installs/repairs the Visual Studio 2022 C++ workload and Inno Setup using winget, then retries the build.

Output:
`installer\CryptoPriceTicker-v2.1.0-x64-Setup.exe`

Existing installations are reused. The setup does not put API keys into the project.

## GitHub Actions

`.github/workflows/build.yml` uses a Windows runner, builds Release x64, installs Inno Setup, and uploads the installer and DLL as artifacts.

This is a native Windows C++ DeskBand, so local builds require Windows C++ build tools. GitHub uses `windows-latest`.
