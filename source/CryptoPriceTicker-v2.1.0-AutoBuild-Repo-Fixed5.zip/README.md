# Cryptocurrency Price Ticker v2.1.0

A lightweight native Windows taskbar DeskBand showing **one or two Binance market pairs** stacked vertically.

## Features

- **Two independent coin slots**: Coin 1 and Coin 2
- Coin 2 can be enabled/disabled
- **Any Binance USDT pair** can be entered from the menu without editing source code
  - `BTC` -> `BTCUSDT`
  - `SOL` -> `SOLUSDT`
  - `XRPUSDT` -> `XRPUSDT`
  - `SOL/USDT` -> `SOLUSDT`
- **Binance Spot** market
- **Binance Futures** market option kept for future/current use
- Current price + 24h percentage change
- Up/down indicator: `▲ +2.35%` / `▼ -1.21%`
- Update frequency: **1 second / 30 seconds / 1 minute / 5 minutes**
- Double-click the ticker to refresh immediately
- Settings persist in `HKCU\Software\CryptoPriceTicker`
- Installer installs to `C:\Program Files\CryptoPriceTicker` and registers the DeskBand automatically
- Upgrading with the installer unregisters the old DLL before replacing it
- Multiple DeskBand instances can be enabled from the Windows taskbar if more than two coins are wanted

## Example

    BTC $108,450.00 ▲ +2.35%
    ETH $3,950.25  ▼ -1.21%

## Configure

Right-click the ticker:

**Coins → Coin 1** or **Coins → Coin 2**

Type any Binance USDT pair symbol. The program automatically normalizes common forms.

**Update Frequency → 1 second / 30 seconds / 1 minute / 5 minutes**

**Market → Binance Spot / Binance Futures**

The symbol must exist as an active pair on the selected Binance market. If it does not, that row will remain on `Refreshing...`.

## One-click installer

The GitHub Actions workflow builds:

`CryptoPriceTicker-v2.1.0-x64-Setup.exe`

The installer registers the DLL automatically. After installation, enable it from:

**Windows taskbar → right-click → Toolbars → Cryptocurrency Price Ticker**

Windows may require the toolbar to be enabled once manually; this is a Windows Explorer DeskBand behavior.

## Build manually

Open `DeskBand.sln` in Visual Studio 2022 with Desktop development with C++ installed.

- Configuration: Release
- Platform: x64
- Build

Output:

`x64\Release\DeskBand.dll`


## One-click local build
Double-click `build-local.bat`. If required Windows build tools are missing, it automatically launches the dependency setup and then retries the build.
