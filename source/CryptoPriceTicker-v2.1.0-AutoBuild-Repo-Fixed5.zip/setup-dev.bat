@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title CryptoPriceTicker v2.1.0 - Automatic Build Setup

:: If called from build-local.bat it is already elevated.
net session >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator permission...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs -Wait"
    exit /b %errorlevel%
)

if not exist logs mkdir logs
set "LOG=%CD%\logs\setup-dev.log"
echo ============================================================ > "%LOG%"
echo CryptoPriceTicker v2.1.0 Automatic Dependency Setup >> "%LOG%"
echo Started: %date% %time% >> "%LOG%"
echo ============================================================ >> "%LOG%"

where winget >nul 2>&1
if errorlevel 1 (
    echo [ERROR] winget is not available.
    echo [ERROR] winget not available.>>"%LOG%"
    pause
    exit /b 1
)

echo [1/4] Checking Visual Studio 2022 C++ Build Tools...
call :log "[1/4] Checking Visual Studio 2022 C++ Build Tools..."
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSINSTALL="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%V in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do if not defined VSINSTALL set "VSINSTALL=%%V"
)

if not defined VSINSTALL (
    echo [INSTALL] Visual Studio 2022 Build Tools...
    call :log "[INSTALL] Visual Studio 2022 Build Tools..."
    winget install --id Microsoft.VisualStudio.2022.BuildTools --exact --source winget --accept-source-agreements --accept-package-agreements --override "--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" >>"%LOG%" 2>&1
    if errorlevel 1 goto failed
)

set "VSINSTALL="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%V in (`"%VSWHERE%" -latest -products * -property installationPath`) do if not defined VSINSTALL set "VSINSTALL=%%V"
)
if not defined VSINSTALL (
    echo [ERROR] Visual Studio installation not found.
    goto failed
)

echo [2/4] Ensuring C++ workload and recommended components...
call :log "[2/4] Ensuring C++ workload and recommended components..."
set "VSINSTALLER=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\setup.exe"
if exist "%VSINSTALLER%" (
    "%VSINSTALLER%" modify --installPath "%VSINSTALL%" --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended --passive --norestart >>"%LOG%" 2>&1
    if errorlevel 1 (
        echo [WARNING] Visual Studio modify returned an error; verifying installation...
        call :log "[WARNING] Visual Studio modify returned an error."
    )
)

:: Wait a little for Visual Studio Installer to finish writing components.
timeout /t 5 /nobreak >nul

echo [3/4] Checking Inno Setup...
call :log "[3/4] Checking Inno Setup..."
call :find_iscc
if not defined ISCC (
    echo [INSTALL] Inno Setup 6...
    call :log "[INSTALL] Inno Setup 6..."
    winget install --id JRSoftware.InnoSetup --exact --source winget --accept-source-agreements --accept-package-agreements --override "/VERYSILENT /NORESTART" >>"%LOG%" 2>&1
    if errorlevel 1 goto failed
    timeout /t 5 /nobreak >nul
    call :find_iscc
)
if not defined ISCC (
    echo [ERROR] Inno Setup compiler ISCC.exe not found.
    call :log "[ERROR] ISCC.exe not found after installation."
    goto failed
)
echo [OK] Inno Setup: !ISCC!
call :log "[OK] Inno Setup: !ISCC!"

echo [4/4] Verifying MSBuild and C++ compiler...
call :log "[4/4] Verifying MSBuild and C++ compiler..."
set "MSBUILD="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%V in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do if not defined MSBUILD set "MSBUILD=%%V"
)
if not defined MSBUILD (
    where msbuild >nul 2>&1
    if not errorlevel 1 set "MSBUILD=msbuild"
)
if not defined MSBUILD goto failed

:: Verify actual x64 compiler exists.
set "VCROOT="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%V in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do if not defined VCROOT set "VCROOT=%%V"
)
set "CLFOUND="
if defined VCROOT (
    for /f "delims=" %%V in ('dir /b /s "%VCROOT%\VC\Tools\MSVC\*\bin\Hostx64\x64\cl.exe" 2^>nul') do if not defined CLFOUND set "CLFOUND=%%V"
)
if not defined CLFOUND (
    echo [WARNING] x64 cl.exe was not located by direct check.
    call :log "[WARNING] x64 cl.exe was not located by direct check."
) else (
    echo [OK] x64 compiler: !CLFOUND!
    call :log "[OK] x64 compiler: !CLFOUND!"
)
echo [OK] MSBuild: !MSBUILD!
call :log "[OK] MSBuild: !MSBUILD!"

echo.
echo SETUP SUCCESSFUL
echo Now build-local.bat can continue automatically.
echo.
pause
exit /b 0

:find_iscc
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC (
    where ISCC >nul 2>&1
    if not errorlevel 1 set "ISCC=ISCC"
)
exit /b 0

:log
echo %~1>>"%LOG%"
exit /b 0

:failed
echo.
echo SETUP FAILED
echo Check: %LOG%
pause
exit /b 1
