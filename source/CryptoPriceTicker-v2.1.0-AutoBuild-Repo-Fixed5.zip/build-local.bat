@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title CryptoPriceTicker v2.1.0 - Local Build

:: Elevate THIS script so child installers can run and return here.
net session >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator permission...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs -Wait"
    exit /b %errorlevel%
)

if not exist logs mkdir logs
set "LOG=%CD%\logs\build-local.log"
echo ================================================== > "%LOG%"
echo CryptoPriceTicker v2.1.0 Local Build >> "%LOG%"
echo Started: %date% %time% >> "%LOG%"
echo ================================================== >> "%LOG%"

echo.
echo ================================================
echo   CryptoPriceTicker v2.1.0 - LOCAL BUILDER
echo ================================================
echo.

call :find_msbuild
if not defined MSBUILD (
    echo [INFO] MSBuild/C++ tools missing. Running automatic setup...
    echo [INFO] Automatic setup started.>>"%LOG%"
    call "%CD%\setup-dev.bat"
    if errorlevel 1 goto setupfailed
    call :find_msbuild
)

if not defined MSBUILD (
    echo [ERROR] MSBuild/C++ Build Tools could not be found.
    echo [ERROR] MSBuild/C++ Build Tools could not be found.>>"%LOG%"
    goto failed
)

echo [OK] MSBuild found: %MSBUILD%
echo [OK] MSBuild found: %MSBUILD%>>"%LOG%"

call :find_iscc
if not defined ISCC (
    echo [INFO] Inno Setup missing. Running automatic setup...
    echo [INFO] Inno Setup setup started.>>"%LOG%"
    call "%CD%\setup-dev.bat"
    if errorlevel 1 goto setupfailed
    call :find_iscc
)

if not defined ISCC (
    echo [ERROR] Inno Setup compiler ISCC.exe could not be found.
    echo [ERROR] Inno Setup compiler ISCC.exe could not be found.>>"%LOG%"
    goto failed
)

echo [OK] Inno Setup found: %ISCC%
echo [OK] Inno Setup found: %ISCC%>>"%LOG%"

echo [1/2] Building Release x64...
echo [1/2] Building Release x64...>>"%LOG%"
if not exist x64 mkdir x64
"%MSBUILD%" "%CD%\DeskBand.sln" /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m >>"%LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "%CD%\x64\Release\DeskBand.dll" goto failed

echo [2/2] Building installer...
echo [2/2] Building installer...>>"%LOG%"
if not exist installer mkdir installer
"%ISCC%" "%CD%\CryptoPriceTicker.iss" >>"%LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "%CD%\installer\CryptoPriceTicker-v2.1.0-x64-Setup.exe" goto failed

echo.
echo ================================================
echo SUCCESS
echo ================================================
echo DLL      : %CD%\x64\Release\DeskBand.dll
echo Installer: %CD%\installer\CryptoPriceTicker-v2.1.0-x64-Setup.exe
echo Log      : %LOG%
echo.
echo You can now install the EXE as Administrator.
echo ================================================
echo Finished: %date% %time%>>"%LOG%"
pause
exit /b 0

:setupfailed
echo [ERROR] Automatic setup failed.>>"%LOG%"
echo.
echo [ERROR] Automatic setup failed. Check logs\setup-dev.log
pause
exit /b 1

:find_msbuild
set "MSBUILD="
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%V in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do (
        if not defined MSBUILD set "MSBUILD=%%V"
    )
)
if not defined MSBUILD (
    where msbuild >nul 2>&1
    if not errorlevel 1 set "MSBUILD=msbuild"
)
exit /b 0

:find_iscc
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC (
    where ISCC >nul 2>&1
    if not errorlevel 1 set "ISCC=ISCC"
)
exit /b 0

:failed
echo.
echo [FAILED] Build failed.
echo Check: %LOG%
echo [FAILED] Finished: %date% %time%>>"%LOG%"
pause
exit /b 1
