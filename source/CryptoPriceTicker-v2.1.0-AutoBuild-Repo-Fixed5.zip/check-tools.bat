@echo off
setlocal
cd /d "%~dp0"
echo CryptoPriceTicker dependency diagnostic
echo.
where winget
echo.
where msbuild
echo.
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" echo ISCC: "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" echo ISCC: "%ProgramFiles%\Inno Setup 6\ISCC.exe"
echo.
pause
