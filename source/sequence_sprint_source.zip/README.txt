Sequence Sprint - memory + reflex hybrid game

How to play:
- 4 colored tiles flash a growing pattern (like Simon Says).
- Watch carefully, then tap the tiles back in the exact same order.
- A shrinking timer bar forces you to respond fast (the action element).
- Each level adds one more step to the pattern (the brain/memory element).
- Wrong tile or running out of time = Game Over, shows your score and
  your all-time best (saved locally, so it persists between plays).
- Tap "Try Again" to restart instantly and try to beat your best.

Why it's addictive:
- Very short session length (each run is 30s-2min) makes "one more try"
  effortless.
- Clear, visible progress (level number climbing) plus a personal best
  creates a simple compulsion loop.
- Combines two different skills (memory recall + fast reaction) so it
  doesn't get boring as quickly as either alone.

How to build:
1. Run "Clean source and output folders" (tick clean_source) first.
2. Upload main.py, requirements.txt, buildozer.spec (or this whole zip)
   into source/.
3. Actions -> Build PC EXE and Android APK -> Run workflow.
   app_name = SequenceSprint
   entry_file = main.py
4. You'll get SequenceSprint.apk (Android, touch controls) and
   SequenceSprint.exe (Windows, mouse-click controls) from the same code.
