import random
import os
from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.clock import Clock
from kivy.core.window import Window

COLORS = {
    0: (0.85, 0.15, 0.15, 1),   # red
    1: (0.15, 0.75, 0.25, 1),   # green
    2: (0.15, 0.35, 0.9, 1),    # blue
    3: (0.95, 0.8, 0.1, 1),     # yellow
}
DIM_ALPHA = 0.45
FLASH_ON_TIME = 0.35
BASE_TIME_LIMIT = 6.0
MIN_TIME_LIMIT = 2.2


class SequenceSprint(FloatLayout):
    def __init__(self, on_game_over, **kwargs):
        super().__init__(**kwargs)
        self.on_game_over = on_game_over
        self.sequence = []
        self.player_pos = 0
        self.level = 1
        self.combo = 0
        self.accepting_input = False
        self.time_left = BASE_TIME_LIMIT
        self.timer_event = None
        self.highscore = self.load_highscore()

        self.status_label = Label(
            text="Watch the pattern...", font_size=26,
            pos_hint={"center_x": 0.5, "top": 0.98}, size_hint=(1, 0.08)
        )
        self.level_label = Label(
            text="Level 1   Best: " + str(self.highscore), font_size=20,
            pos_hint={"center_x": 0.5, "top": 0.90}, size_hint=(1, 0.06)
        )
        self.timer_bar = ProgressBar(
            max=BASE_TIME_LIMIT, value=BASE_TIME_LIMIT,
            pos_hint={"center_x": 0.5, "top": 0.84}, size_hint=(0.9, 0.03)
        )
        self.add_widget(self.status_label)
        self.add_widget(self.level_label)
        self.add_widget(self.timer_bar)

        self.grid = GridLayout(
            cols=2, spacing=14, padding=30,
            pos_hint={"center_x": 0.5, "center_y": 0.4}, size_hint=(0.85, 0.65)
        )
        self.buttons = {}
        for idx in range(4):
            btn = Button(background_normal="", background_color=self._dim(COLORS[idx]))
            btn.bind(on_release=lambda inst, i=idx: self.on_tile_tap(i))
            self.grid.add_widget(btn)
            self.buttons[idx] = btn
        self.add_widget(self.grid)

        Clock.schedule_once(lambda dt: self.next_level(), 1.0)

    def _dim(self, color):
        r, g, b, a = color
        return (r, g, b, DIM_ALPHA)

    def highlight(self, idx, on):
        color = COLORS[idx] if on else self._dim(COLORS[idx])
        self.buttons[idx].background_color = color

    def highscore_path(self):
        try:
            base = App.get_running_app().user_data_dir
        except Exception:
            base = "."
        return os.path.join(base, "sequence_sprint_highscore.txt")

    def load_highscore(self):
        try:
            with open(self.highscore_path(), "r") as f:
                return int(f.read().strip())
        except Exception:
            return 0

    def save_highscore(self, value):
        try:
            with open(self.highscore_path(), "w") as f:
                f.write(str(value))
        except Exception:
            pass

    def next_level(self):
        self.accepting_input = False
        self.player_pos = 0
        self.sequence.append(random.randint(0, 3))
        self.status_label.text = "Watch the pattern..."
        self.level_label.text = "Level " + str(self.level) + "   Best: " + str(self.highscore)
        self.play_sequence(0)

    def play_sequence(self, step):
        if step >= len(self.sequence):
            Clock.schedule_once(lambda dt: self.start_input_phase(), 0.4)
            return
        idx = self.sequence[step]
        self.highlight(idx, True)
        Clock.schedule_once(lambda dt: self._end_flash(idx, step), FLASH_ON_TIME)

    def _end_flash(self, idx, step):
        self.highlight(idx, False)
        gap = max(0.15, 0.45 - self.level * 0.015)
        Clock.schedule_once(lambda dt: self.play_sequence(step + 1), gap)

    def start_input_phase(self):
        self.accepting_input = True
        self.status_label.text = "Your turn! Tap the pattern."
        self.time_left = max(MIN_TIME_LIMIT, BASE_TIME_LIMIT - self.level * 0.25)
        self.timer_bar.max = self.time_left
        self.timer_bar.value = self.time_left
        if self.timer_event:
            self.timer_event.cancel()
        self.timer_event = Clock.schedule_interval(self._tick_timer, 0.05)

    def _tick_timer(self, dt):
        self.time_left -= dt
        self.timer_bar.value = max(0, self.time_left)
        if self.time_left <= 0:
            self.timer_event.cancel()
            self.fail_round()

    def on_tile_tap(self, idx):
        if not self.accepting_input:
            return
        self.highlight(idx, True)
        Clock.schedule_once(lambda dt: self.highlight(idx, False), 0.15)

        expected = self.sequence[self.player_pos]
        if idx == expected:
            self.player_pos += 1
            self.combo += 1
            if self.player_pos == len(self.sequence):
                self.accepting_input = False
                if self.timer_event:
                    self.timer_event.cancel()
                self.level += 1
                self.status_label.text = "Correct! Next level..."
                Clock.schedule_once(lambda dt: self.next_level(), 0.9)
        else:
            self.fail_round()

    def fail_round(self):
        self.accepting_input = False
        if self.timer_event:
            self.timer_event.cancel()
        final_score = self.level - 1
        if final_score > self.highscore:
            self.highscore = final_score
            self.save_highscore(self.highscore)
        self.on_game_over(final_score, self.highscore)


class RootLayout(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.start_game()

    def start_game(self):
        self.game = SequenceSprint(on_game_over=self.show_game_over, size_hint=(1, 1))
        self.add_widget(self.game)

    def show_game_over(self, score, highscore):
        self.remove_widget(self.game)
        box = FloatLayout()
        box.add_widget(Label(
            text="Game Over!\nScore: " + str(score) + "\nBest: " + str(highscore),
            font_size=40, halign="center",
            pos_hint={"center_x": 0.5, "center_y": 0.6}, size_hint=(0.9, 0.3)
        ))
        retry_btn = Button(
            text="Try Again", font_size=28,
            pos_hint={"center_x": 0.5, "center_y": 0.35}, size_hint=(0.5, 0.11)
        )
        retry_btn.bind(on_release=lambda *_: self.restart(box))
        box.add_widget(retry_btn)
        self.add_widget(box)

    def restart(self, box):
        self.remove_widget(box)
        self.start_game()


class SequenceSprintApp(App):
    def build(self):
        Window.clearcolor = (0.06, 0.06, 0.09, 1)
        return RootLayout()


if __name__ == "__main__":
    SequenceSprintApp().run()
