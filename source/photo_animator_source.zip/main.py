import os
from io import BytesIO
from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image as KivyImage
from kivy.graphics.texture import Texture
from kivy.clock import Clock
from PIL import Image as PILImage

FRAME_COUNT = 24
FRAME_DELAY_MS = 120
ZOOM_MAX = 1.35


def start_dir():
    candidates = ["/storage/emulated/0", os.path.expanduser("~"), os.getcwd()]
    for c in candidates:
        if os.path.isdir(c):
            return c
    return "."


def pil_to_texture(pil_img):
    img = pil_img.convert("RGBA")
    data = img.tobytes()
    texture = Texture.create(size=img.size, colorfmt="rgba")
    texture.blit_buffer(data, colorfmt="rgba", bufferfmt="ubyte")
    texture.flip_vertical()
    return texture


def build_zoom_frames(path, frame_count=FRAME_COUNT, zoom_max=ZOOM_MAX):
    src = PILImage.open(path).convert("RGB")
    w, h = src.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    src = src.crop((left, top, left + side, top + side))
    out_size = (480, 480)

    frames = []
    for i in range(frame_count):
        t = i / max(1, frame_count - 1)
        zoom = 1.0 + (zoom_max - 1.0) * t
        crop_side = int(side / zoom)
        cx, cy = side // 2, side // 2
        left_c = max(0, cx - crop_side // 2)
        top_c = max(0, cy - crop_side // 2)
        cropped = src.crop((left_c, top_c, left_c + crop_side, top_c + crop_side))
        frame = cropped.resize(out_size, PILImage.LANCZOS)
        frames.append(frame)
    return frames


class PickerScreen(FloatLayout):
    def __init__(self, on_picked, **kwargs):
        super().__init__(**kwargs)
        self.on_picked = on_picked

        self.chooser = FileChooserIconView(
            path=start_dir(),
            filters=["*.png", "*.jpg", "*.jpeg"],
            size_hint=(1, 0.85), pos_hint={"x": 0, "top": 1}
        )
        self.add_widget(self.chooser)

        bar = BoxLayout(size_hint=(1, 0.15), pos_hint={"x": 0, "y": 0})
        self.status = Label(text="Pick a photo, then tap Animate")
        pick_btn = Button(text="Animate", size_hint=(0.35, 1))
        pick_btn.bind(on_release=self.confirm_pick)
        bar.add_widget(self.status)
        bar.add_widget(pick_btn)
        self.add_widget(bar)

    def confirm_pick(self, *_):
        if not self.chooser.selection:
            self.status.text = "No file selected -- tap an image first."
            return
        path = self.chooser.selection[0]
        self.status.text = "Processing..."
        Clock.schedule_once(lambda dt: self.on_picked(path), 0.1)


class PreviewScreen(FloatLayout):
    def __init__(self, image_path, on_back, **kwargs):
        super().__init__(**kwargs)
        self.on_back = on_back
        self.frame_index = 0

        self.status = Label(
            text="Building animation...", font_size=22,
            pos_hint={"center_x": 0.5, "top": 0.98}, size_hint=(1, 0.08)
        )
        self.add_widget(self.status)

        self.preview_img = KivyImage(
            pos_hint={"center_x": 0.5, "center_y": 0.55}, size_hint=(0.9, 0.7)
        )
        self.add_widget(self.preview_img)

        bar = BoxLayout(size_hint=(1, 0.12), pos_hint={"x": 0, "y": 0})
        back_btn = Button(text="Back")
        save_btn = Button(text="Save as GIF")
        back_btn.bind(on_release=lambda *_: self.on_back())
        save_btn.bind(on_release=self.save_gif)
        bar.add_widget(back_btn)
        bar.add_widget(save_btn)
        self.add_widget(bar)

        self.frames = []
        Clock.schedule_once(lambda dt: self.build(image_path), 0.1)

    def build(self, path):
        self.frames = build_zoom_frames(path)
        self.status.text = "Preview -- tap Save as GIF to export"
        Clock.schedule_interval(self.tick, FRAME_DELAY_MS / 1000)

    def tick(self, dt):
        if not self.frames:
            return
        frame = self.frames[self.frame_index]
        self.preview_img.texture = pil_to_texture(frame)
        self.frame_index = (self.frame_index + 1) % len(self.frames)

    def save_gif(self, *_):
        if not self.frames:
            return
        try:
            out_dir = App.get_running_app().user_data_dir
        except Exception:
            out_dir = "."
        out_path = os.path.join(out_dir, "photo_animation.gif")
        self.frames[0].save(
            out_path, save_all=True, append_images=self.frames[1:],
            duration=FRAME_DELAY_MS, loop=0
        )
        self.status.text = "Saved: " + out_path


class RootLayout(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.show_picker()

    def show_picker(self):
        self.clear_widgets()
        self.add_widget(PickerScreen(on_picked=self.show_preview, size_hint=(1, 1)))

    def show_preview(self, path):
        self.clear_widgets()
        self.add_widget(PreviewScreen(path, on_back=self.show_picker, size_hint=(1, 1)))


class PhotoAnimatorApp(App):
    def build(self):
        return RootLayout()


if __name__ == "__main__":
    PhotoAnimatorApp().run()
