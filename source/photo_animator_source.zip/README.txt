Photo Animator - image to animated GIF (no FFmpeg/OpenCV needed)

What it does:
1. Browse your device storage and pick a photo (png/jpg/jpeg).
2. The app applies a smooth zoom-in (Ken Burns) effect across 24 frames,
   generated entirely with Pillow -- no video codecs involved.
3. Preview the animation live inside the app (frames cycle automatically).
4. Tap "Save as GIF" to export an animated .gif to the app's private
   storage folder (path shown on screen after saving).

Why GIF instead of MP4:
True video (.mp4) encoding needs FFmpeg or OpenCV compiled for Android,
which is a large, fragile, slow build in CI (often 60-90+ minutes and
prone to breaking). Pillow's GIF support is pure Python + a small native
codec that has a stable, well-supported Android build recipe, so this
version is reliable to build through your existing pipeline today.

How to build:
1. Run "Clean source and output folders" (tick clean_source) first.
2. Upload main.py, requirements.txt, buildozer.spec (or this zip) into
   source/.
3. Actions -> Build PC EXE and Android APK -> Run workflow.
   app_name = PhotoAnimator
   entry_file = main.py
4. Install PhotoAnimator.apk on your Android phone. Note: on first launch
   Android may prompt for storage/photo permission -- allow it so the
   file browser can see your pictures.

Limitations of this version:
- No video input support (extracting frames from an existing video needs
  FFmpeg/OpenCV, which this version deliberately avoids for build
  reliability).
- Output is an animated GIF, not an MP4. GIFs play natively in most
  gallery apps, messengers, and browsers, but are not identical to video
  files.
