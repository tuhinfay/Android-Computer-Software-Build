Random Line Changer - HTML to Android app test

This is your exact HTML/JS code, unchanged, saved as index.html.

Why unchanged: the workflow's HTML/web path uses Capacitor, which wraps
this file (and any others you put alongside it) inside a native Android
WebView. Whatever your HTML does in a normal browser, it does identically
inside the app -- no rewriting needed for plain client-side HTML/CSS/JS
like this (no server calls, no external APIs, purely local logic).

How to build:
1. Run the "Clean source and output folders" workflow first (tick
   clean_source) to clear whatever was in source/ before.
2. Upload this index.html (or the whole zip) into source/.
3. Actions -> Build PC EXE and Android APK -> Run workflow.
   app_name = RandomLine
   (entry_file input is ignored for HTML projects, leave it default)
4. build-android detects "index.html" -> type=html -> wraps it with
   Capacitor -> builds RandomLine.apk via Gradle.
5. build-windows will ALSO detect the same index.html -> wraps it with
   Electron -> builds RandomLine.exe (a portable one-file Windows app).

Expected app behavior: opens fullscreen with a dark background, shows one
of five lines of text, and changes to a random line every 2 seconds --
identical to opening the HTML file in a browser.
