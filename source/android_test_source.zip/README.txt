Android pipeline test - minimal project

Purpose: confirm the Android build step in build.yml actually works,
before testing with more complex projects (games etc).

Contents:
- main.py: the smallest possible Kivy app -- just shows a text label.
- requirements.txt: kivy
- buildozer.spec: pre-filled, titled AndroidTest.

How to use:
1. Drop these 3 files (or this whole zip) into source/ in your repo.
2. Actions -> Build PC EXE and Android APK -> Run workflow.
   app_name = AndroidTest
   entry_file = main.py
3. Check the build-android job:
   - If it succeeds: the pipeline itself is fine, and any future failure
     with a bigger project (like the CatchGame) is specific to that
     project's code, not the pipeline.
   - If it still fails: send me the raw .txt log again (Download log
     archive from the run page) and we fix the pipeline itself.
